<?php
/**
 *  Plugin Name: Hungry Plugin
 *  Plugin URI:  http://themeforest.net/user/SubatomicThemes
 *  Author:      Subatomic Themes
 *  Author URI:  http://themeforest.net/user/SubatomicThemes
 *  Description: This is a complimentary plugin for use with the "Hungry" theme. It provides you with your recipes post type, custom taxonomies, meta-boxes and shortcodes.
 *  Version:     1.0.2
 *  License:     See "Licensing" Folder
 *  License URI: See "Licensing" Folder
 *  Domain Path: /languages
 */

/**
 *  Make the plugin available for translation.
 *  ---------------------------------------------------------------------------
 */
load_plugin_textdomain( 'hungry_plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' ); 

/**
 *  Include all necessary files.
 *  ---------------------------------------------------------------------------
 */
require_once( plugin_dir_path( __FILE__ ) . 'inc/hungry-post-types.php' );
require_once( plugin_dir_path( __FILE__ ) . 'inc/hungry-taxonomies.php' );
require_once( plugin_dir_path( __FILE__ ) . 'inc/hungry-meta-boxes.php' );
require_once( plugin_dir_path( __FILE__ ) . 'inc/hungry-shortcodes.php' );
require_once( plugin_dir_path( __FILE__ ) . 'inc/hungry-attachment-fields.php' );
require_once( plugin_dir_path( __FILE__ ) . 'inc/cmb2/init.php' );