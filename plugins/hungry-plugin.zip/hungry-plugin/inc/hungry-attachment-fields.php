<?php
/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.2
 *  ---------------------------------------------------------------------------
 *
 *  Create a new field for attachments called "class". To be used in the
 *  homepage gallery.
 *
 *  1.0.1 - Added more output sanitization.
 *
 */

/*
 *  Add attachment fields to edit.
 */
function hungry_image_attachment_fields_to_edit( $form_fields, $post ) {

	$form_fields['hungry_class'] = array(
	
		'label'       => esc_html__( 'Class', 'hungry_plugin' ),
		'input'       => 'text',
		'application' => 'image',
		'value'       => get_post_meta( $post->ID, '_hungry_class', true ),
		'helps'       => esc_html__( 'Enter a class name.', 'hungry_plugin' )
		
	);
	
	return $form_fields;

}
add_filter( 'attachment_fields_to_edit', 'hungry_image_attachment_fields_to_edit', null, 2 );

/*
 *  Add attachment fields to save.
 */
function hungry_image_attachment_fields_to_save( $post, $attachment ) {
	
	if( isset( $attachment['hungry_class'] ) ) {
	
		update_post_meta( $post['ID'], '_hungry_class', $attachment['hungry_class'] );
	
	}
	
	return $post;
	
}
add_filter( 'attachment_fields_to_save', 'hungry_image_attachment_fields_to_save', null, 2 );

if( ! function_exists( 'hungry_get_attachment' ) ) :
/*
 *  Helper function to retrieve attachment attributes.
 */
function hungry_get_attachment( $attachment_id ) {

	$attachment = get_post( $attachment_id );
	return array(
	
		'hungry_class' => get_post_meta( $attachment->ID, '_hungry_class', true ),
		'alt'          => get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true ),
		'caption'      => $attachment->post_excerpt,
		'description'  => $attachment->post_content,
		'href'         => get_permalink( $attachment->ID ),
		'title'        => $attachment->post_title
		
	);

}
endif;