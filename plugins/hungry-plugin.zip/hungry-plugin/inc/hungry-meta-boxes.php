<?php
/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.2
 *  ---------------------------------------------------------------------------
 *
 *  Custom meta boxes for use with the "Recipe" post type, pages and posts.
 *
 *  1.0.2 - Added more Meta Boxes for individual Header Images.
 *  1.0.1 - Added more output sanitization.
 *
 */

function hungry_metaboxes( array $meta_boxes ) {

	/*
	 *  Get the currency symbol set in the theme options.
	 */
	if( function_exists( 'get_hungry_currency_symbol' ) ) {
	
		global $hungry_options;
		$currency_symbol = isset( $hungry_options['hungry_currency_symbol'] ) ? $hungry_options['hungry_currency_symbol'] : 'dol';
		$hungry_currency_symbol = get_hungry_currency_symbol( $currency_symbol );
		
	} else {
	
		$hungry_currency_symbol = '&dollar;';
	
	}
	
	$prefix = '_hungry_';

	$meta_boxes['recipe_options'] = array(

		'id'           => 'hungry_recipe_options',
		'title'        => esc_html__( 'Recipe Options', 'hungry_plugin' ),
		'object_types' => array( 'hungry_recipe' ),
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       => array(

			array(

				'name'         => esc_html__( 'Price on Menu', 'hungry_plugin' ),
				'desc'         => '',
				'id'           => $prefix . 'recipe_price',
				'type'         => 'text_money',
				'before_field' => $hungry_currency_symbol

			),
			
			array(

				'name' => esc_html__( 'Special Item', 'hungry_plugin' ),
				'desc' => esc_html__( 'Make this recipe a featured item on the menu.', 'hungry_plugin' ),
				'id'   => $prefix . 'recipe_special',
				'type' => 'checkbox'

			),
			
			array(

				'name' => esc_html__( 'Link to recipe from menu', 'hungry_plugin' ),
				'desc' => esc_html__( 'Allow users to visit the recipe\'s main page from menus.', 'hungry_plugin' ),
				'id'   => $prefix . 'recipe_link',
				'type' => 'checkbox'

			),
			
			array(

				'name' => esc_html__( 'Tooltip Text', 'hungry_plugin' ),
				'desc' => esc_html__( 'Some text to display when the user hovers over the price.', 'hungry_plugin' ),
				'id'   => $prefix . 'recipe_tooltip',
				'type' => 'text'

			),
			
			array(

				'name' => esc_html__( 'Warning Text', 'hungry_plugin' ),
				'desc' => esc_html__( 'Some warning text to display at the end. Useful if you need to warn customers that the meal contains a certain ingredient.', 'hungry_plugin' ),
				'id'   => $prefix . 'recipe_warning',
				'type' => 'text'

			),
			
			array(

				'name' => esc_html__( 'Widget Excerpt', 'hungry_plugin' ),
				'desc' => esc_html__( 'This will display a tiny excerpt when displayed inside a widget. Keep this to around 4 - 6 words.', 'hungry_plugin' ),
				'id'   => $prefix . 'recipe_small_excerpt',
				'type' => 'text'

			),
			
			array(

				'name'    => esc_html__( 'Page Layout', 'hungry_plugin' ),
				'desc'    => esc_html__( 'This is for single page views.', 'hungry_plugin' ),
				'id'      => $prefix . 'recipe_layout',
				'type'    => 'radio',
				'options' => array(
				
					'left'  => esc_html__( 'Content on the Left', 'hungry' ),
					'right' => esc_html__( 'Content on the Right', 'hungry' ),
				
				),
				'default' => 'right'
				
			)

		)
	
	);
	
	$meta_boxes['page_options'] = array(

		'id'           => 'hungry_page_options',
		'title'        => esc_html__( 'Section Options (Only used within the "one-page" page template)', 'hungry_plugin' ),
		'object_types' => array( 'page' ),
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       => array(
		
			array(

				'name'    => esc_html__( 'Padding Top', 'hungry_plugin' ),
				'desc'    => esc_html__( 'Amount of padding at the top (in pixels).', 'hungry_plugin' ),
				'id'      => $prefix . 'section_padding_top',
				'type'    => 'text_small',
				'default' => '140'

			),
			
			array(

				'name'    => esc_html__( 'Padding Bottom', 'hungry_plugin' ),
				'desc'    => esc_html__( 'Amount of padding at the bottom (in pixels).', 'hungry_plugin' ),
				'id'      => $prefix . 'section_padding_bottom',
				'type'    => 'text_small',
				'default' => '140'

			),
			
			array(

				'name'    => esc_html__( 'Enable Automatic Parapgraph Tags (wpautop)', 'hungry_plugin' ),
				'desc'    => wp_kses_data( __( 'When displaying this post within a section using the homepage template, <code>&lt;p&gt;</code> tags are omitted so that other shortcodes can be displayed correctly. However, any paragraph text will also have their tags removed. Check this option to enable them.', 'hungry_plugin' ) ),
				'id'      => $prefix . 'section_wpautop',
				'type'    => 'checkbox'

			)
		
		)
		
	);
	
	$meta_boxes['header_image'] = array(

		'id'           => 'hungry_header_image_upload',
		'title'        => esc_html__( 'Header Image', 'hungry_plugin' ),
		'object_types' => array( 'post', 'page', 'hungry_recipe' ),
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true,
		'fields'       => array(

			array(

				'name' => esc_html__( 'Upload A Header Image', 'hungry_plugin' ),
				'desc' => esc_html__( 'Select a Header Image to upload for this post. If none is selected, then the WordPress Custom Header Image will be used instead.', 'hungry_plugin' ),
				'id'   => $prefix . 'header_image',
				'type' => 'file'

			),
			
			array(

				'name' => esc_html__( 'Full Width Background', 'hungry_plugin' ),
				'desc' => esc_html__( 'Check this option to force the image to cover the full width of the screen. Works with WordPress Custom Header Image too.', 'hungry_plugin' ),
				'id'   => $prefix . 'header_image_cover',
				'type' => 'checkbox'

			)
			
		)
		
	);

return $meta_boxes;

}
add_filter( 'cmb2_meta_boxes', 'hungry_metaboxes' );