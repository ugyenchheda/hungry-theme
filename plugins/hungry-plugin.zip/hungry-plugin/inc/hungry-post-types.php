<?php
/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.2
 *  ---------------------------------------------------------------------------
 *
 *  Create the "Recipe" post type for use with the "Hungry" theme.
 *
 *  1.0.1 - Added more output sanitization.
 *
 */

if ( ! function_exists( 'hungry_recipe_post_type' ) ) :
/**
 *  Create the post type.
 *  ---------------------------------------------------------------------------
 */
function hungry_recipe_post_type() {

	$labels = array(
	
		'name'                => esc_html( _x( 'Recipes', 'Post Type General Name', 'hungry_plugin' ) ),
		'singular_name'       => esc_html( _x( 'Recipe', 'Post Type Singular Name', 'hungry_plugin' ) ),
		'menu_name'           => esc_html__( 'Recipes', 'hungry_plugin' ),
		'parent_item_colon'   => esc_html__( 'Parent Recipe:', 'hungry_plugin' ),
		'all_items'           => esc_html__( 'All Recipes', 'hungry_plugin' ),
		'view_item'           => esc_html__( 'View Recipe', 'hungry_plugin' ),
		'add_new_item'        => esc_html__( 'Add New Recipe', 'hungry_plugin' ),
		'add_new'             => esc_html__( 'Add New', 'hungry_plugin' ),
		'edit_item'           => esc_html__( 'Edit Recipe', 'hungry_plugin' ),
		'update_item'         => esc_html__( 'Update Recipe', 'hungry_plugin' ),
		'search_items'        => esc_html__( 'Search Recipes', 'hungry_plugin' ),
		'not_found'           => esc_html__( 'Not found', 'hungry_plugin' ),
		'not_found_in_trash'  => esc_html__( 'Not found in Trash', 'hungry_plugin' )
		
	);
	$rewrite = array(
	
		'slug'                => 'recipes',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true
		
	);
	$args = array(
	
		'label'               => esc_html__( 'hungry_recipe', 'hungry_plugin' ),
		'description'         => esc_html__( 'A post type to store and show information about food recipes.', 'hungry_plugin' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes' ),
		'taxonomies'          => array( 'food_menu' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 34.5,
		'menu_icon'           => 'dashicons-carrot',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'rewrite'             => $rewrite,
		'capability_type'     => 'page'
		
	);
	
	register_post_type( 'hungry_recipe', $args );

}
add_action( 'init', 'hungry_recipe_post_type', 0 );
endif;