<?php
/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.2
 *  ---------------------------------------------------------------------------
 *
 *  Create and add Shortcodes to the TinyMCE Editor.
 *
 *  1.0.2 - Slug names are now used to display menus.
 *  1.0.1 - Added more output sanitization.
 *
 */ 

/**
 *
 *  Shortcode : Columns
 *  Tag       : [col]$content[/col]
 *  Atts      : pre, grid, suf, tgrid, mgrid, dhide, thide, mhide,
 *	            dfirst, tfirst, mfirst, dlast, tlast, mlast
 *  ---------------------------------------------------------------------------
 *
 *  Requires Unsemantic Grid CSS framework to use.
 *
 */
function hungry_columns( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'pre'    => '0',     // Prefix                             - int
		'grid'   => '100',   // Column Width                       - int
		'suf'    => '0',     // Suffix                             - int
		'tgrid'  => '100',   // Tablet Column Width                - int
		'mgrid'  => '100',   // Mobile Column Width                - int
		'dhide'  => 'false', // Hide on Desktop?                   - bool
		'thide'  => 'false', // Hide on Tablet?                    - bool
		'mhide'  => 'false', // Hide on Mobile?                    - bool
		'dfirst' => 'false', // Is it the FIRST column on Desktop? - bool
		'tfirst' => 'false', // Is it the FIRST column on Tablet?  - bool
		'mfirst' => 'false', // Is it the FIRST column on Mobile?  - bool
		'dlast'  => 'false', // Is it the LAST column on Desktop?  - bool
		'tlast'  => 'false', // Is it the LAST column on Tablet?   - bool
		'mlast'  => 'false'  // Is it the LAST column on Mobile?   - bool

	), $atts ) );

	$dhide            = strtolower( $dhide );
	$thide            = strtolower( $thide );
	$mhide            = strtolower( $mhide );
	$dfirst           = strtolower( $dfirst );
	$tfirst           = strtolower( $tfirst );
	$mfirst           = strtolower( $mfirst );
	$dlast            = strtolower( $dlast );
	$tlast            = strtolower( $tlast );
	$mlast            = strtolower( $mlast );
	
	$prefix           = '';
	$suffix           = '';
	$tablet           = '';
	$mobile           = '';
	$hide_on_desktop  = '';
	$hide_on_tablet   = '';
	$hide_on_mobile   = '';
	$first_on_desktop = '';
	$first_on_tablet  = '';
	$first_on_mobile  = '';
	$last_on_desktop  = '';
	$last_on_tablet   = '';
	$last_on_mobile   = '';
	
	// Set up class names
	if( ! $pre   == null ) { $prefix = 'prefix-' . $pre . ' '; }
	if( ! $suf   == null ) { $suffix = ' suffix-' . $suf; }
	if( ! $tgrid == null ) { $tablet = ' tablet-grid-' . $tgrid; }
	if( ! $mgrid == null ) { $mobile = ' mobile-grid-' . $mgrid; }
	
	if( $dhide == 'true' ) { $hide_on_desktop = ' hide-on-desktop'; }
	if( $thide == 'true' ) { $hide_on_tablet  = ' hide-on-tablet'; }
	if( $mhide == 'true' ) { $hide_on_mobile  = ' hide-on-mobile'; }
	
	if( $dfirst == 'true' ) { $first_on_desktop = ' first-on-desktop'; }
	if( $tfirst == 'true' ) { $first_on_tablet  = ' first-on-tablet';  }
	if( $mfirst == 'true' ) { $first_on_mobile  = ' first-on-mobile';  }
	
	if( $dlast == 'true' ) { $last_on_desktop = ' last-on-desktop'; }
	if( $tlast == 'true' ) { $last_on_tablet  = ' last-on-tablet';  }
	if( $mlast == 'true' ) { $last_on_mobile  = ' last-on-mobile';  }
	
	$html  = '<div class="' . esc_attr( $prefix ) . 'grid-' . esc_attr( $grid ) . esc_attr( $suffix ) . esc_attr( $tablet ) . esc_attr( $mobile ) . esc_attr( $hide_on_desktop ) . esc_attr( $hide_on_tablet ) . esc_attr( $hide_on_mobile ) . esc_attr( $first_on_desktop ) . esc_attr( $first_on_tablet ) . esc_attr( $first_on_mobile ) . esc_attr( $last_on_desktop ) . esc_attr( $last_on_tablet ) . esc_attr( $last_on_mobile ) . '">' . "\n";
	$html .= do_shortcode( $content ) . "\n";
	$html .= '</div>';
	
	return $html;
	
}
add_shortcode( 'col'    , 'hungry_columns' );
add_shortcode( 'column' , 'hungry_columns' );

/**
 *
 *  Shortcode : Food Menu
 *  Tag       : [hungry_menu]$content[/hungry_menu]
 *  Atts      : menu, slug
 *  ---------------------------------------------------------------------------
 *
 *  Use this shortcode to display menus on any page. Best used with column
 *  shortcodes for more creative layouts.
 *
 */
function hungry_menu( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'menu' => ''

	), $atts ) );
	
	/*
	 *  Grab the order and currency settings from the theme options.
	 */
	global $hungry_options;
	
	$currency_symbol = isset( $hungry_options['hungry_currency_symbol'] ) ? $hungry_options['hungry_currency_symbol'] : 'dol';
	$menu_order_by   = empty( $hungry_options['hungry_menu_order_by'] )   ? 'none' : $hungry_options['hungry_menu_order_by'];
	$menu_order      = empty( $hungry_options['hungry_menu_order'] )      ? 'DESC' : $hungry_options['hungry_menu_order'];
	
	$slug = '';
	
	/*
	 *  Check if its an ID. If so, convert it to the name.
	 */
	if( is_numeric( $menu ) ) {
		
		$menu = get_term( $menu, 'food_menu' );
		$slug = $menu->slug;
		$menu = $menu->name;
			
	} else {
		
		$term = get_term_by( 'slug', $menu, 'food_menu' );
		$slug = $term->slug;
		$menu = $term->name;
		
	}
	
	ob_start();
	
	?>
	<!-- START Menu -->
	<div class="hungry-menu wow zoomIn" data-wow-duration="2s" data-wow-offset="250">
		<h2 class="hungry-menu-title header-divider"><?php echo esc_html( $menu ); ?></h2>
		
		<ol class="hungry-menu-list">
		
			<?php
			
			$args = array(
			
				'post_type'      => 'hungry_recipe',
				'posts_per_page' => -1,
				'orderby'        => esc_attr( $menu_order_by ),
				'order'          => esc_attr( $menu_order ),
				'tax_query'      => array(
				
					array(
					
						'taxonomy' => 'food_menu',
						'field'    => 'slug',
						'terms'    => esc_attr( $slug )
						
					),
					
				)
				
			);
			
			$food_menu = new WP_Query( $args );
			
			if( $food_menu->have_posts() ) : 
				
				while( $food_menu->have_posts() ) : $food_menu->the_post();
			
					$recipe_price   = strip_tags( get_post_meta( get_the_ID(), '_hungry_recipe_price', true ) );
					$recipe_special = strip_tags( get_post_meta( get_the_ID(), '_hungry_recipe_special', true ) );
					$recipe_link    = strip_tags( get_post_meta( get_the_ID(), '_hungry_recipe_link', true ) );
					$recipe_tooltip = strip_tags( get_post_meta( get_the_ID(), '_hungry_recipe_tooltip', true ) );
					$recipe_warning = strip_tags( get_post_meta( get_the_ID(), '_hungry_recipe_warning', true ) );
					$special_class  = '';
					$tooltip_class  = '';
				
					if( $recipe_special ) :
					
						$special_class = ' special';
					
					endif;
					
					if( $recipe_tooltip ) :
					
						$tooltip_class = ' special-tooltip';
					
					endif;
					
					if( $recipe_warning ) :
					
						$warning_text = sprintf(
						
							'<span class="menu-info"><i class="fa fa-exclamation-circle"></i>%s</span>',
							esc_html( $recipe_warning )
						
						);
						
					endif;
					
				?>
		
				<!-- START Menu Item -->
				<li class="hungry-menu-item<?php echo esc_attr( $special_class ); ?>">
					<?php hungry_post_thumbnail(); ?>
					<div class="hungry-menu-item-container">
					<?php if( $recipe_link ) : ?>
						<a href="<?php the_permalink(); ?>" class="hungry-menu-item-header">
					<?php else : ?>
						<div class="hungry-menu-item-header">
					<?php endif; ?>
							<h3 class="hungry-menu-item-title"><?php the_title(); ?></h3>
							<h4 class="hungry-menu-item-price<?php echo esc_attr( $tooltip_class ); ?>"<?php if( $recipe_tooltip ) : ?> title="<?php echo esc_attr( $recipe_tooltip ); ?>"<?php endif; ?>>
								<span class="currency-symbol"><?php echo get_hungry_currency_symbol( $currency_symbol ); ?></span>
								<?php echo $recipe_price; ?>
							</h4>
					<?php if( $recipe_link ) : ?>
						</a>
					<?php else : ?>
						</div>
					<?php endif; ?>
						<div class="hungry-menu-item-excerpt">
							<?php the_excerpt(); ?>
							<?php
							
								if( $recipe_warning ) :
							
									echo wp_kses_post( $warning_text );
							
								endif;
							
							?>
						</div>
					</div>
				</li>
				<!-- END Menu Item -->
				
				<?php endwhile; ?>
				
				<?php wp_reset_postdata(); ?>
				
			<?php endif; ?>
		
		</ol>
		
	</div>
	<!-- END Menu -->
	<?php
	
	return ob_get_clean();
	
}
add_shortcode( 'hungry_menu' , 'hungry_menu' );

/**
 *
 *  Shortcode : Divider
 *  Tag       : [divider]
 *  Atts      : type
 *  ---------------------------------------------------------------------------
 *
 *  Divider shortcode. Can be nested in column shortcode.
 *
 */
function hungry_divider( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'type' => ''

	), $atts ) );
	
	$type_class = '';
	
	if( 'line' == $type ) {
	
		$type_class = ' line';
	
	}
	
	$html  = '<!-- START Divider -->' . "\n";
	$html .= '<div class="hungry-menu wow fadeIn" data-wow-duration="2s" data-wow-offset="250">' . "\n";
	$html .= '<div class="hungry-menu-divider' . esc_attr( $type_class ) . '"></div>' . "\n";
	$html .= '</div>' . "\n";
	$html .= '<!-- END Divider -->' . "\n";
	
	return $html;
	
}
add_shortcode( 'divider', 'hungry_divider' );

/**
 *
 *  Shortcode : Section Intro
 *  Tag       : [intro]
 *  Atts      : title, subtitle
 *  ---------------------------------------------------------------------------
 *
 *  Use this shortcode to display section headings.
 *
 */
function hungry_section_intro( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'title'    => '',
		'subtitle' => ''

	), $atts ) );
	
	if( $title || $subtitle ) {
	
		$html  = '<!-- START Section Heading -->' . "\n";
		$html .= '<div class="wow fadeInDown" data-wow-duration="2s" data-wow-offset="250">' . "\n";
		$html .= '<header class="section-heading">' . "\n";
		
		if( $title ) {
		
			$html .= '<h2 class="section-heading-title">' . esc_html( $title ) . '</h2>' . "\n";
			
		}
		
		if( $subtitle ) {
		
			$html .= '<div class="section-heading-subtitle-container tilt-left">' . "\n";
			$html .= '<h4 class="section-heading-subtitle">' . esc_html( $subtitle ) . '</h4>' . "\n";
			$html .= '</div>' . "\n";
			
		}
		
		$html .= '</header>' . "\n";
		$html .= '</div>' . "\n";
		$html .= '<!-- END Section Heading -->' . "\n";
	
	}
	
	return $html;
	
}
add_shortcode( 'intro', 'hungry_section_intro' );

/**
 *
 *  Shortcode : Section Heading (Alt)
 *  Tag       : [intro_alt]
 *  Atts      : title
 *  ---------------------------------------------------------------------------
 *
 *  An alternate version of the section heading.
 *
 */
function hungry_section_heading_alt( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'title' => ''

	), $atts ) );
	
	$html  = '';
	
	if( $title ) {
	
		$html  ='<!-- START Section Heading -->' . "\n";
		$html .='<div class="wow fadeIn" data-wow-duration="2s" data-wow-offset="250">' . "\n";
		$html .='<h1 class="section-heading-alt-title">' . wp_kses( $title, array( 'span' => array() ) ) . '</h1>' . "\n";
		$html .='</div>' . "\n";
		$html .='<!-- END Section Heading -->' . "\n";
	
	}
	
	return $html;
	
}
add_shortcode( 'intro_alt', 'hungry_section_heading_alt' );

/**
 *
 *  Shortcode : Button
 *  Tag       : [button]
 *  Atts      : style, text, url
 *  ---------------------------------------------------------------------------
 *
 *  A simple button shortcode.
 *
 */
function hungry_button( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'style' => '',
		'text'  => '',
		'url'   => ''

	), $atts ) );
	
	$class = '';
	if( 'dark' == $style ) {
	
		$class = ' dark';
	
	}
	$html = '<a class="hungry-button' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>';
	
	return $html;
	
}
add_shortcode( 'button', 'hungry_button' );

/**
 *
 *  Shortcode : Dual Images
 *  Tag       : [dual_images]
 *  Atts      : main, inset
 *  ---------------------------------------------------------------------------
 *
 *  Displays a small image inset to a larger image.
 *
 */
function hungry_dual_images( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'main'  => '',
		'inset' => ''

	), $atts ) );
	
	$html  = '<!-- START Dual Images -->' . "\n";
	$html .= '<div class="wow rotateIn" data-wow-duration="2s" data-wow-offset="250">' . "\n";
	$html .= '<div class="about-images">' . "\n";
	
	// Don't output empty URLs...
	if( $main ) {
	
		$html .= '<img class="about-main" src="' . esc_url( $main ) . '" alt="" />' . "\n";
		
	}
	
	if( $inset ) {
	
		$html .= '<img class="about-inset" src="' . esc_url( $inset ) . '" alt="" />' . "\n";
		
	}
	$html .= '</div>' . "\n";
	$html .= '</div>' . "\n";
	$html .= '<!-- END Dual Images -->' . "\n";
	
	return $html;
	
}
add_shortcode( 'dual_images', 'hungry_dual_images' );

/**
 *
 *  Shortcode : Testimonial
 *  Tag       : [testimonial]$content[/testimonial]
 *  Atts      : cite, thumbnail
 *  ---------------------------------------------------------------------------
 *
 *  A simple testimonial with a quote, thumbnail image, and author details. 
 *  Used in the "Testimonials" section.
 *
 */
function hungry_testimonial( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'cite'      => '',
		'thumbnail' => ''

	), $atts ) );
	
	$html  ='<!-- START Testimonial -->' . "\n";
	$html .='<div class="hungry-testimonial">' . "\n";
	$html .='<blockquote>' . wp_kses( $content, array( 'br' => array() ) ) . '</blockquote>' . "\n";
	
	if( $thumbnail ) {
	
		$html .='<img src="' . esc_url( $thumbnail ) . '" alt="" />' . "\n";
		
	}
	
	if( $cite ) {
	
		$html .='<cite>' . wp_kses( $cite, array( 'a' => array( 'href' => array(), 'target' => array(), 'title' => array() ) ) ) . '</cite>' . "\n";
		
	}
	
	$html .='</div>' . "\n";
	$html .='<!-- END Testimonial -->' . "\n";
	
	return $html;
	
}
add_shortcode( 'testimonial', 'hungry_testimonial' );

/**
 *
 *  Shortcode : Staff Member
 *  Tag       : [staff]$content[/staff]
 *  Atts      : name, role, thumbnail, icon1, icon2, icon3, link1, link2, link3
 *				tooltip1, tooltip2, tooltip3
 *  ---------------------------------------------------------------------------
 *
 *  This shortcode will display basic information about a member of staff, such
 *  as name, position (role), thumbnail image and up to three social media icons.
 *
 */
function hungry_staff_member( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'name'      => '',
		'role'      => '',
		'thumbnail' => '',
		'icon1'     => '',
		'icon2'     => '',
		'icon3'     => '',
		'link1'     => '',
		'link2'     => '',
		'link3'     => '',
		'tooltip1'  => '',
		'tooltip2'  => '',
		'tooltip3'  => ''

	), $atts ) );
	
	$html  = '';
	$html .= '<div class="hungry-staff-member">' . "\n";
	
	if( $name || $role || $thumbnail ) {
	
		$html .= '<header>' . "\n";
		
		if( $thumbnail ) {
		
			$html .= '<img src="' . esc_url( $thumbnail ) . '" class="hungry-staff-member-thumbnail" alt="" />' . "\n";
			
		}
		
		if( $name ) {
		
			$html .= '<h3 class="hungry-staff-member-title">' . esc_html( $name ) . '</h3>' . "\n";
			
		}
		
		if( $role ) {
		
			$html .= '<h4 class="hungry-staff-member-role">' . esc_html( $role ) . '</h4>' . "\n";
			
		}
		
		$html .= '</header>' . "\n";
		
	} // End name, role and thumbnail check.
	
	if( $content ) {
	
		$html .= '<div class="hungry-staff-member-content">' . "\n";
		$html .= do_shortcode( $content );
		$html .= '</div>' . "\n";
	
	}
	
	$html .= '<footer>' . "\n";
	
	if( $icon1 || $icon2 || $icon3 ) {
	
		$html .= '<ul class="hungry-staff-member-social-icons">' . "\n";
		
		if( $icon1 && $link1 ) {
		
			$html .= "\t" . '<li><a href="' . esc_url( $link1 ) . '"';
			if( $tooltip1 ) {
			
				$html .= ' class="team-tooltip" title="' . esc_attr( $tooltip1 ) . '"';
			
			}
			$html .= '><i class="' . esc_attr( $icon1 ) . '"></i></a></li>' . "\n";
			
		}
		
		if( $icon2 && $link2 ) {
		
			$html .= "\t" . '<li><a href="' . esc_url( $link2 ) . '"';
			if( $tooltip2 ) {
			
				$html .= ' class="team-tooltip" title="' . esc_attr( $tooltip2 ) . '"';
			
			}
			$html .= '><i class="' . esc_attr( $icon2 ) . '"></i></a></li>' . "\n";
			
		}
		
		if( $icon3 && $link3 ) {
		
			$html .= "\t" . '<li><a href="' . esc_url( $link3 ) . '"';
			if( $tooltip3 ) {
			
				$html .= ' class="team-tooltip" title="' . esc_attr( $tooltip3 ) . '"';
			
			}
			$html .= '><i class="' . esc_attr( $icon3 ) . '"></i></a></li>' . "\n";
			
		}
		$html .= '</ul>' . "\n";
		
	} // End Icons check.
	
	$html .= '</footer>' . "\n";
	$html .= '</div>' . "\n";
	
	return $html;
	
}
add_shortcode( 'staff', 'hungry_staff_member' );

/**
 *
 *  Shortcode : Section
 *  Tag       : [section]
 *  Atts      : id
 *  ---------------------------------------------------------------------------
 *
 *  Used to display page content as a custom section within the homepage template.
 *
 */
function hungry_section( $atts, $content = null ) {

	extract( shortcode_atts( array(
	
		'id' => 'page-1'
		
	), $atts ) );
	
	$page_id = '1';
	if( $id ) {
	
		$page_id = str_replace( 'page-', '', $id );
	
	}
	
	$page_id                = absint( $page_id );
	$section                = get_post( $page_id );
	$section_padding_top    = strip_tags( get_post_meta( $section->ID, '_hungry_section_padding_top', true ) );
	$section_padding_bottom = strip_tags( get_post_meta( $section->ID, '_hungry_section_padding_bottom', true ) );
	$section_wpautop        = strip_tags( get_post_meta( $section->ID, '_hungry_section_wpautop', true ) );
	
	/*
	 *  Don't add the "style" attribute if there's no need.
	 */
	$padding = '';
	if( $section_padding_top ) {
	
		$padding = ' style="padding-top: ' . esc_attr( $section_padding_top ) . 'px;"';
			
	} elseif( $section_padding_bottom ) {
	
		$padding = ' style="padding-bottom: ' . esc_attr( $section_padding_bottom ) . 'px;"';
	
	} 
	
	if( $section_padding_top && $section_padding_bottom ) {
	
		$padding = ' style="padding-top: ' . esc_attr( $section_padding_top ) . 'px; padding-bottom: ' . esc_attr( $section_padding_bottom ) . 'px;"';
		
	}
	
	$html  = '<!-- START Section - Custom -->' . "\n";
	$html .= '<section id="hungry-custom-section-' . esc_attr( $section->ID ) . '"' . wp_kses_data( $padding ) . '>' . "\n";
	$html .= '<div class="grid-container">' . "\n";
	
	if( 'on' == $section_wpautop ) {
	
		$html .= wpautop( do_shortcode( $section->post_content ) );
		
	} else {
	
		$html .= do_shortcode( $section->post_content ) . "\n";
	
	}
	$html .= '</div>' . "\n";
	$html .= '</section>' . "\n";
	$html .= '<!-- END Section - Custom -->' . "\n";
	
	return $html;
	
}
add_shortcode( 'section', 'hungry_section' );

/**
 *  Include all Scripts and Styles for the Back End.
 *  ---------------------------------------------------------------------------
 */
function hungry_plugin_admin_scripts() {

	wp_enqueue_style( 'hungry-admin', plugins_url( '/css/hungry-shortcodes.css', __FILE__), array(), '1.0.0', 'all' );
	
}
add_action( 'admin_enqueue_scripts' , 'hungry_plugin_admin_scripts' );

if( ! function_exists( 'hungry_content_filter' ) ) :
/**
 *  Only the plugin's shortcodes will be regex'ed for stray <p> and <br /> tags 
 *  generated by wpautop() and ONLY the ones that need it.
 *  ---------------------------------------------------------------------------
 */
function hungry_content_filter( $content ) {
 
	/*
	 *  Custom Shortcodes requiring the fix
	 */
	$block = join( '|' , array(
	
		'col',
		'column'
		
	) );
	 
	/*
	 *  Opening Tag
	 */
	$rep = preg_replace( "/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/", "[$2$3]", $content );
	
	/*
	 *  Closing Tag
	 */
	$rep = preg_replace( "/(<p>)?\[\/($block)](<\/p>|<br \/>)?/", "[/$2]", $rep );
	 
	return $rep;
 
}
add_filter( 'the_content', 'hungry_content_filter' );
endif;

/**
 *  Register the button with the TinyMCE Editor.
 *  ---------------------------------------------------------------------------
 */
function hungry_add_button() {

	global $typenow;
	
	if( ! current_user_can( 'edit_posts' ) && ! current_user_can( 'edit_pages' ) ) { return; }
	
	// Post types to show the button on
	if( ! in_array( $typenow, array( 'post', 'page', 'hungry_recipe' ) ) ) { return; }	
	
	if( get_user_option( 'rich_editing' ) == 'true' ) {
	
		add_filter( 'mce_external_plugins', 'hungry_add_tinymce_plugin');
		add_filter( 'mce_buttons', 'hungry_register_button');
		
	}

}
add_action( 'admin_head', 'hungry_add_button' );

function hungry_add_tinymce_plugin( $plugin_array ) {

	$plugin_array['hungry_button'] = plugins_url( '/js/hungry-shortcodes.js', __FILE__ );
	return $plugin_array;

}

function hungry_register_button( $buttons ) {

	array_push( $buttons, 'hungry_button' );
	return $buttons;

}

/**
 *  Get the taxonomy terms for use in the TimyMCE editor.
 *  ---------------------------------------------------------------------------
 */
function hungry_admin_head() {

	if( ! taxonomy_exists( 'food_menu' ) ) {
	
		return;
	
	}

	$terms  = get_terms( 'food_menu' );
	$output = '';
	
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
	
		$output  = '<!-- For TinyMCE Shortcodes -->' . "\n";
		$output .= '<script type="text/javascript">' . "\n";
		$output .= 'var hungry_terms = [' . "\n";
		
		foreach( $terms as $term ) {
	
			$output .= '"' . esc_attr( $term->name ) . '",' . "\n"; 
	
		}
		
		$output .= '];' . "\n";
		$output .= '</script>' . "\n";
		$output .= '<!-- For TinyMCE Shortcodes -->' . "\n";
		
	}
	
	echo $output;
	
}
foreach ( array( 'post.php', 'post-new.php' ) as $hook ) {

     add_action( "admin_head-$hook", 'hungry_admin_head' );
	 
}