<?php
/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.2
 *  ---------------------------------------------------------------------------
 *
 *  Create the taxonomy "Menu" to use with the "Recipe" post type. For use with
 *  the "Hungry" theme.
 *
 *  1.0.1 - Added more output sanitization.
 *
 */ 

if ( ! function_exists( 'hungry_taxonomy_food_menu' ) ) :
/**
 *  Create the taxonomy.
 *  ---------------------------------------------------------------------------
 */
function hungry_taxonomy_food_menu() {

	$labels = array(
	
		'name'                       => esc_html( _x( 'Menus', 'Taxonomy General Name', 'hungry_plugin' ) ),
		'singular_name'              => esc_html( _x( 'Menu', 'Taxonomy Singular Name', 'hungry_plugin' ) ),
		'menu_name'                  => esc_html__( 'Menus', 'hungry_plugin' ),
		'all_items'                  => esc_html__( 'All Menus', 'hungry_plugin' ),
		'parent_item'                => esc_html__( 'Parent Menu', 'hungry_plugin' ),
		'parent_item_colon'          => esc_html__( 'Parent Menu:', 'hungry_plugin' ),
		'new_item_name'              => esc_html__( 'New Menu Name', 'hungry_plugin' ),
		'add_new_item'               => esc_html__( 'Add New Menu', 'hungry_plugin' ),
		'edit_item'                  => esc_html__( 'Edit Menu', 'hungry_plugin' ),
		'update_item'                => esc_html__( 'Update Menu', 'hungry_plugin' ),
		'separate_items_with_commas' => esc_html__( 'Separate menus with commas', 'hungry_plugin' ),
		'search_items'               => esc_html__( 'Search menus', 'hungry_plugin' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove menus', 'hungry_plugin' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used menus', 'hungry_plugin' ),
		'not_found'                  => esc_html__( 'Menu Not Found', 'hungry_plugin' )
		
	);
	
	$rewrite = array(
	
		'slug'                       => 'menu',
		'with_front'                 => true,
		'hierarchical'               => false
		
	);
	
	$args = array(
	
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => $rewrite
		
	);
	
	register_taxonomy( 'food_menu', array( 'hungry_recipe' ), $args );

}
add_action( 'init', 'hungry_taxonomy_food_menu', 0 );

endif;