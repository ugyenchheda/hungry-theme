/**
 *
 *  Plugin:		Hungry Plugin
 *  Author:		Subatomic Themes
 *  Author URI:	http://themeforest.net/user/SubatomicThemes
 *  Version:	1.0.0
 *  ---------------------------------------------------------------------------
 *
 *  Shortcode generator used within the TinyMCE (visual) editor.
 *
 */ 
(function() {

	tinymce.PluginManager.add( 'hungry_button', function( editor, url ) {
	
		editor.addButton( 'hungry_button', {

			title : 'Shortcodes',
			type  : 'menubutton',
			icon  : 'icon dashicons-media-code',
			menu  : 
			[

				{
				
					text    : 'Columns (Simple)',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.windowManager.open({
						
							title  : 'Column Properties',
							body   :
							[{
							
								type  	: 'listbox',
								name  	: 'grid',
								tooltip	: 'Width of the Column displayed on Desktop View',
								label 	: 'Width on Desktop', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
								
							{
								type   	: 'listbox',
								name   	: 'tabletgrid',
								tooltip	: 'Width of the Column displayed on Tablet View',
								label  	: 'Width on Tablet', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
							
							{
								type   	: 'listbox',
								name   	: 'mobilegrid',
								tooltip	: 'Width of the Column displayed on Mobile View',
								label  	: 'Width on Mobile', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							}],

							onsubmit: function(e) {
							
								editor.insertContent( 
								
									'[col grid="' + e.data.grid +
									'" tgrid="'   + e.data.tabletgrid + 
									'" mgrid="'   + e.data.mobilegrid + 
									'"]<br />'    + editor.selection.getContent() + '<br />[/col]<br />' );
								
							}
						
						});
						
					}
				},
			
				{
				
					text    : 'Columns (Advanced)',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.windowManager.open({
						
							title  : 'Column Properties',
							body   :
							[{
							
								type  	: 'listbox',
								name  	: 'grid',
								tooltip	: 'Width of the Column displayed on Desktop View',
								label 	: 'Width on Desktop', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
								
							{
								type   	: 'listbox',
								name   	: 'tabletgrid',
								tooltip	: 'Width of the Column displayed on Tablet View',
								label  	: 'Width on Tablet', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
							
							{
								type   	: 'listbox',
								name   	: 'mobilegrid',
								tooltip	: 'Width of the Column displayed on Mobile View',
								label  	: 'Width on Mobile', 'values': [
								
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
								
							{
								type   	: 'listbox',
								name   	: 'prefix',
								tooltip	: 'Space BEFORE the column on desktop view',
								label  	: 'Prefix', 'values': [
								
									{ text: 'None', value: '' },
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
							
							{
								type   	: 'listbox',
								name   	: 'suffix',
								tooltip	: 'Space AFTER the column on desktop view',
								label  	: 'Suffix', 'values': [
								
									{ text: 'None', value: '' },
									{ text: '100%', value: '100' },
									{ text: '5%', value: '5' },
									{ text: '10%', value: '10' },
									{ text: '15%', value: '15' },
									{ text: '20%', value: '20' },
									{ text: '25%', value: '25' },
									{ text: '30%', value: '30' },
									{ text: '35%', value: '35' },
									{ text: '40%', value: '40' },
									{ text: '45%', value: '45' },
									{ text: '50%', value: '50' },
									{ text: '55%', value: '55' },
									{ text: '60%', value: '60' },
									{ text: '65%', value: '65' },
									{ text: '70%', value: '70' },
									{ text: '75%', value: '75' },
									{ text: '80%', value: '80' },
									{ text: '85%', value: '85' },
									{ text: '90%', value: '90' },
									{ text: '95%', value: '95' },
									{ text: '33%', value: '33' },
									{ text: '66%', value: '66' }
									
								]
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'dfirst',
								label	: 'First Column on Desktop'
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'tfirst',
								label	: 'First Column on Tablet'
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'mfirst',
								label	: 'First Column on Mobile'
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'dlast',
								label	: 'Last Column on Desktop'
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'tlast',
								label	: 'Last Column on Tablet'
							},
							
							{	type	: 'spacer' },
							
							{
								type	: 'radio',
								name	: 'mlast',
								label	: 'Last Column on Mobile'
							}],
							onsubmit: function(e) {
							
								pre = '';
								suf = '';
								
								if( e.data.prefix ) {
								
									pre = 'pre="' + e.data.prefix + '" ';
								
								}
								
								if( e.data.suffix ) {
								
									suf = 'suf="' + e.data.suffix + '" ';
								
								}
							
								editor.insertContent( 
								
									'[col ' + pre + suf + 'grid="' + e.data.grid +
									'" tgrid="'   + e.data.tabletgrid + 
									'" mgrid="'   + e.data.mobilegrid + 
									'" dfirst="'  + e.data.dfirst + 
									'" tfirst="'  + e.data.tfirst + 
									'" mfirst="'  + e.data.mfirst + 
									'" dlast="'   + e.data.dlast + 
									'" tlast="'   + e.data.tlast + 
									'" mlast="'   + e.data.mlast +
									'"]<br />'    + editor.selection.getContent() + '<br />[/col]<br />' );
								
							}
						
						});
						
					}
				},
				
				{
				
					text    : 'Food Menu',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						/*
						 *  Sort the terms into an object
						 */
						var menus_list = [];
						for( var key in hungry_terms ) {
						
							if( hungry_terms.hasOwnProperty(key) ) {
							
								menus_list.push({
								
									text  : hungry_terms[key],
									value : hungry_terms[key]
								
								})
							
							}
						
						}
						
						editor.windowManager.open({
						
							title  : 'Food Menu Properties',
							body   :
							[{
							
								type  	: 'listbox',
								name  	: 'menu',
								tooltip	: 'Choose menu',
								label 	: 'Menus', 'values': menus_list
								
							}],

							onsubmit: function(e) {
							
								editor.insertContent( '[hungry_menu menu="' + e.data.menu + '"]' );
								
							}
						
						});
						
					}
				},
				
				{
				
					text    : 'Divider',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.windowManager.open({
						
							title  : 'Divider Properties',
							body   :
							[{
							
								type  	: 'listbox',
								name  	: 'type',
								tooltip	: 'Choose menu',
								label 	: 'Divider Type', 'values': [
									
									{ text: 'Line',  value: 'line' },
									{ text: 'Fancy', value: 'fancy' }
									
								]
								
							}],

							onsubmit: function(e) {
							
								editor.insertContent( '[divider type="' + e.data.type + '"]' );
								
							}
						
						});
						
					}
					
				},
				
				{
				
					text    : 'Intro Heading',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.windowManager.open({
						
							title  : 'Heading Properties',
							body   :
							[{
							
								type  	: 'textbox',
								name  	: 'title',
								label 	: 'Title'
								
							},
							
							{
							
								type  	: 'textbox',
								name  	: 'subtitle',
								label 	: 'Subtitle'
								
							}],

							onsubmit: function(e) {
							
								editor.insertContent( '[intro title="' + e.data.title + '" subtitle="' + e.data.subtitle + '"]' );
								
							}
						
						});
						
					}
					
				},
				
				{
				
					text    : 'Button',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.windowManager.open({
						
							title  : 'Button Properties',
							body   :
							[{
							
								type  	: 'listbox',
								name  	: 'style',
								label 	: 'Button Style', 'values': [
									
									{ text: 'Light', value: 'light' },
									{ text: 'Dark',  value: 'dark' }
									
								]
								
							},
							
							{
							
								type    : 'textbox',
								name    : 'text',
								label   : 'Button Text'
								
							},
							
							{
							
								type  	: 'textbox',
								name  	: 'url',
								tooltip : 'Example: http://www.example.com',
								label 	: 'Button URL'
								
							}],

							onsubmit: function(e) {
							
								editor.insertContent( '[button style="' + e.data.style + '" text="' + e.data.text + '" url="' + e.data.url + '"]' );
								
							}
						
						});
						
					}
					
				},
				
				{
				
					text    : 'Font Awesome List',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.insertContent(
							
							'<ul class="fa-ul">' +
								'<li><i class="fa-li fa fa-pagelines"></i><strong>6</strong> <abbr title="Table Spoons">tbsp</abbr> Chicken Tikka Masala Paste</li>' +
								'<li><i class="fa-li fa fa-pagelines"></i><strong>2</strong> Red peppers, deseeded</li>' +
								'<li><i class="fa-li fa fa-pagelines"></i><strong>8</strong> Chicken breasts, cut into <strong>2cm</strong> cubes</li>' +
							'</ul>'
					
						);
					
					}
						
				},
				
				{
				
					text    : 'Open Table Form',
					icon	: 'icon dashicons-arrow-right',
					onClick : function(e){
					
						editor.insertContent(
							
							'<div class="hungry-open-table"><br />' +
							'[open-table-widget title="Booking Form" widget_style="bare-bones" max_width="100%" display_option="2" lookup_city="London, Manchester" pre_content="If you\'re new in town, why not use the form below to find one of our restaurants." post_content="Please allow up to 24 hours for a confirmation of your booking. Thanks!" time_start="5:00pm" time_end="9:30pm" time_increment="30" max_seats="8" label_city="Choose a City" label_date="Choose a Date" label_time="Choose a Time" label_party="How Many People?" input_submit="Find a Table!"]<br />' +
							'</div>'
					
						);
								
					}
				
				}
				
			] // menu

		});
			
	});

})();